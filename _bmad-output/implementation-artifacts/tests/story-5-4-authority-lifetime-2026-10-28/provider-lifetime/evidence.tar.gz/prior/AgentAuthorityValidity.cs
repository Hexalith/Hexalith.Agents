namespace Hexalith.Agents.Server.Ports;

/// <summary>Retains a current authorization's exclusive deadline and checked clock across asynchronous work.</summary>
/// <remarks>This transient bound grants no authority and never enters a command payload or persisted metadata.</remarks>
public sealed class AgentAuthorityValidity
{
    private readonly object _gate = new();
    private readonly TimeProvider _clock;
    private readonly DateTimeOffset _validUntil;
    private DateTimeOffset _checkedAt;
    private bool _invalid;

    /// <summary>Initializes a bound after current actor and role evidence have both been verified.</summary>
    /// <param name="clock">The same clock used to evaluate current evidence.</param>
    /// <param name="checkedAt">The verified authorization completion instant.</param>
    /// <param name="validUntil">The earliest exclusive actor or role evidence deadline.</param>
    public AgentAuthorityValidity(TimeProvider clock, DateTimeOffset checkedAt, DateTimeOffset validUntil)
    {
        ArgumentNullException.ThrowIfNull(clock);
        _clock = clock;
        _checkedAt = checkedAt;
        _validUntil = validUntil;
        _invalid = checkedAt == default || checkedAt.Offset != TimeSpan.Zero
            || validUntil.Offset != TimeSpan.Zero || validUntil <= checkedAt;
    }

    /// <summary>Checks exclusive expiry and per-await clock ordering; a failed bound never becomes valid again.</summary>
    public bool IsCurrent
    {
        get
        {
            lock (_gate)
            {
                DateTimeOffset now = _clock.GetUtcNow();
                _invalid |= now < _checkedAt || now >= _validUntil || now.Offset != TimeSpan.Zero;
                _checkedAt = now;
                return !_invalid;
            }
        }
    }

    /// <summary>Returns a safe label without identity or authority timestamps.</summary>
    /// <returns>The transient bound type label.</returns>
    public override string ToString() => nameof(AgentAuthorityValidity);
}
