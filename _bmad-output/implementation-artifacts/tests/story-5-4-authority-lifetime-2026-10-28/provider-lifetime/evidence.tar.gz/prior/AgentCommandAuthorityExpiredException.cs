namespace Hexalith.Agents.Server.Ports;

/// <summary>Refuses command construction when current authorization expires or its checked clock rolls back.</summary>
public sealed class AgentCommandAuthorityExpiredException() : InvalidOperationException("CurrentAuthorityUnavailable")
{
}
