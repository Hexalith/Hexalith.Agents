from pathlib import Path
p=Path('src/Hexalith.Agents.Server/Application/Agents/EventStoreProviderCatalogOperations.cs');s=p.read_text()
# Every operation checks cancellation before using a returned current context.
lines=s.splitlines();out=[]
for line in lines:
 out.append(line)
 if 'AgentAdministrationContext context = await ' in line:
  out.append('        '+('ct' if ', ct)' in line else 'cancellationToken')+'.ThrowIfCancellationRequested();')
s='\n'.join(out)+'\n'
# A previously verified submission receipt remains Submitted when later status authority is unavailable.
start=s.index('    private async ValueTask<AgentOperationResult<AgentSetupWriteOutcome>> GetCommandOutcomeCoreAsync');end=s.index('    /// <inheritdoc />',start)
part=s[start:end]
part=part.replace('''            return AgentOperationResult<AgentSetupWriteOutcome>.Failed(AgentOperationErrorCode.NotAuthorized);''','''            return hasSubmissionReceipt
                ? AgentOperationResult<AgentSetupWriteOutcome>.Succeeded(AgentSetupWriteOutcome.Submitted)
                : AgentOperationResult<AgentSetupWriteOutcome>.Failed(AgentOperationErrorCode.NotAuthorized);''',1)
part=part.replace('''            cancellationToken.ThrowIfCancellationRequested();

            // A status''','''            cancellationToken.ThrowIfCancellationRequested();
            context.Authority?.ThrowIfNotCurrent();

            // A status''')
part=part.replace('''        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return AgentOperationResult<AgentSetupWriteOutcome>.Succeeded(AgentSetupWriteOutcome.UnableToVerify);
        }''','''        catch (AgentCommandAuthorityExpiredException)
        {
            return hasSubmissionReceipt
                ? AgentOperationResult<AgentSetupWriteOutcome>.Succeeded(AgentSetupWriteOutcome.Submitted)
                : AgentOperationResult<AgentSetupWriteOutcome>.Failed(AgentOperationErrorCode.NotAuthorized);
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (!context.HasCurrentAuthority)
            {
                return hasSubmissionReceipt
                    ? AgentOperationResult<AgentSetupWriteOutcome>.Succeeded(AgentSetupWriteOutcome.Submitted)
                    : AgentOperationResult<AgentSetupWriteOutcome>.Failed(AgentOperationErrorCode.NotAuthorized);
            }
            return AgentOperationResult<AgentSetupWriteOutcome>.Succeeded(AgentSetupWriteOutcome.UnableToVerify);
        }''')
s=s[:start]+part+s[end:]
# Enablement inspection is Platform-authorized and its two model/two head reads share the original bound.
start=s.index('    public async ValueTask<AgentOperationResult<TenantProviderEnablementInspectionResult>> GetTenantEnablementAsync');end=s.index('    /// <inheritdoc />',start)
part=s[start:end]
part=part.replace('''            if (read.Value?.IsScopedTo''','''            cancellationToken.ThrowIfCancellationRequested();
            context.Authority?.ThrowIfNotCurrent();
            if (read.Value?.IsScopedTo''')
part=part.replace('ReadPlatformModelAsync(cancellationToken)','ReadPlatformModelAsync(cancellationToken, context.Authority)')
part=part.replace('read.Value?.LastSequenceNumber ?? 0, cancellationToken)','read.Value?.LastSequenceNumber ?? 0, cancellationToken, context.Authority)')
part=part.replace('providerId, modelId, cancellationToken).ConfigureAwait(false)','providerId, modelId, cancellationToken, context.Authority).ConfigureAwait(false)')
part=part.replace('''        catch (Exception exception) when (exception is not OperationCanceledException)''','''        catch (AgentCommandAuthorityExpiredException)
        {
            return AgentOperationResult<TenantProviderEnablementInspectionResult>.Succeeded(
                new(ProviderCatalogInspectionStatus.NotAuthorized, null, null), correlationId: options?.CorrelationId);
        }
        catch (Exception exception) when (exception is not OperationCanceledException)''')
part=part.replace('''            return AgentOperationResult<TenantProviderEnablementInspectionResult>.Failed(''','''            cancellationToken.ThrowIfCancellationRequested();
            if (!context.HasCurrentAuthority)
            {
                return AgentOperationResult<TenantProviderEnablementInspectionResult>.Succeeded(
                    new(ProviderCatalogInspectionStatus.NotAuthorized, null, null), correlationId: options?.CorrelationId);
            }
            return AgentOperationResult<TenantProviderEnablementInspectionResult>.Failed(''')
s=s[:start]+part+s[end:]
# Complete preflight stays bounded; do not re-evaluate it after an acknowledged submission.
start=s.index('        ProviderCatalogReadModel? platform;',s.index('public async ValueTask<AgentOperationResult<ProviderCatalogCommandAcceptance>> SetTenantEnablementAsync'))
end=s.index('    /// <inheritdoc />',start)
s=s[:start]+'''        try
        {
            ProviderCatalogReadModel? platform = await ReadPlatformModelAsync(cancellationToken, context.Authority).ConfigureAwait(false);
            ProviderCatalogEntryView? entry = platform?.Entries.FirstOrDefault(item =>
                item.ProviderId == command.ProviderId && item.ModelId == command.ModelId);
            if (entry is null)
            {
                string entryId = ProviderCatalogIdentity.EntryId(command.ProviderId, command.ModelId);
                bool absent = await ProviderCatalogReadFreshness.HasHeadAsync(_gateway,
                    ProviderCatalogIdentity.PlatformTenantId, ProviderCatalogAggregate.Domain, entryId,
                    platform?.StreamSequences.GetValueOrDefault(entryId) ?? 0,
                    cancellationToken, context.Authority).ConfigureAwait(false);
                return AgentOperationResult<ProviderCatalogCommandAcceptance>.Failed(
                    absent ? AgentOperationErrorCode.NotFound : AgentOperationErrorCode.Unavailable);
            }

            if (!await ProviderCatalogReadFreshness.IsPlatformCurrentAsync(_gateway, platform,
                command.ProviderId, command.ModelId, cancellationToken, context.Authority).ConfigureAwait(false))
            {
                return AgentOperationResult<ProviderCatalogCommandAcceptance>.Failed(AgentOperationErrorCode.Unavailable);
            }

            if (entry.Status != ProviderModelStatus.Enabled || entry.DataHandling is not { DataHandlingVersion: >= 1 })
            {
                return AgentOperationResult<ProviderCatalogCommandAcceptance>.Failed(AgentOperationErrorCode.Blocked);
            }

            context.Authority?.ThrowIfNotCurrent();
            SetTenantProviderModelEnablement trusted = command with { CurrentTerms = entry.DataHandling };
            return await WriteTenantAsync(command.ProviderId, command.ModelId, command.TenantId, options,
                (request, ct) => _catalog.SetTenantEnablementAsync(request, trusted, ct),
                platformAuthority: true, cancellationToken).ConfigureAwait(false);
        }
        catch (AgentCommandAuthorityExpiredException)
        {
            return AgentOperationResult<ProviderCatalogCommandAcceptance>.Failed(AgentOperationErrorCode.NotAuthorized);
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return AgentOperationResult<ProviderCatalogCommandAcceptance>.Failed(context.HasCurrentAuthority
                ? AgentOperationErrorCode.Unavailable : AgentOperationErrorCode.NotAuthorized);
        }
    }

'''+s[end:]
s=s.replace('''            ?? new(ProviderCatalogInspectionStatus.Unavailable, []);
        if (visible.Status''','''            ?? new(ProviderCatalogInspectionStatus.Unavailable, []);
        cancellationToken.ThrowIfCancellationRequested();
        if (!context.IsAuthorized || visible.Status == ProviderCatalogInspectionStatus.NotAuthorized)
        {
            return AgentOperationResult<ProviderCatalogCommandAcceptance>.Failed(AgentOperationErrorCode.NotAuthorized);
        }
        if (visible.Status''')
# Platform list/detail reads: keep all projection/freshness/view work inside the same checked lifetime.
start=s.index('    private async ValueTask<AgentOperationResult<ProviderCatalogInspectionResult>> ReadAsync(');end=s.index('    private async ValueTask<AgentOperationResult<ProviderCatalogCommandAcceptance>> WriteAsync(',start)
s=s[:start]+'''    private async ValueTask<AgentOperationResult<ProviderCatalogInspectionResult>> ReadAsync(
        AgentOperationOptions? options,
        Func<ProviderCatalogReadModel?, string, ProviderCatalogInspectionResult> create,
        string? providerId,
        string? modelId,
        CancellationToken cancellationToken,
        int? expectedCapabilityVersion = null)
    {
        AgentAdministrationContext context = await _contextProvider.GetContextAsync(true, cancellationToken).ConfigureAwait(false);
        cancellationToken.ThrowIfCancellationRequested();
        string? correlationId = options?.CorrelationId;
        if (!context.HasCurrentAuthority || !context.IsPlatformOperator)
        {
            return AgentOperationResult<ProviderCatalogInspectionResult>.Succeeded(
                ProviderCatalogInspectionResult.NotAuthorized(), correlationId: correlationId);
        }

        try
        {
            ReadModelEntry<ProviderCatalogReadModel> entry = await _readModelStore.GetAsync<ProviderCatalogReadModel>(
                _options.Value.StateStoreName, ProviderCatalogReadModelAddresses.Detail(ProviderCatalogIdentity.PlatformTenantId),
                cancellationToken).ConfigureAwait(false);
            cancellationToken.ThrowIfCancellationRequested();
            context.Authority?.ThrowIfNotCurrent();
            bool knownHeadsCurrent = await ProviderCatalogReadFreshness.IsPlatformCurrentAsync(_gateway, entry.Value,
                providerId, modelId, cancellationToken, context.Authority).ConfigureAwait(false);
            ProviderCatalogInspectionResult result = create(entry.Value, ProviderCatalogIdentity.PlatformTenantId);
            if (!knownHeadsCurrent || providerId is null)
            {
                // A list cannot claim a complete inventory from checks of its projected stream names alone.
                result = result with
                {
                    Status = ProviderCatalogInspectionStatus.Success,
                    Entries = knownHeadsCurrent && providerId is null ? result.Entries : [],
                    Freshness = AgentSetupFreshness.Stale,
                    TruthState = AgentSetupTruthState.AuthoritativePending,
                    ProjectedCommandMessageIds = null,
                };
            }
            else if (result.Status == ProviderCatalogInspectionStatus.EntryNotFound && expectedCapabilityVersion is null)
            {
                result = result with
                {
                    Freshness = AgentSetupFreshness.Current,
                    TruthState = AgentSetupTruthState.ProjectionConfirmed,
                    ProjectedCommandMessageIds = null,
                };
            }
            context.Authority?.ThrowIfNotCurrent();
            return AgentOperationResult<ProviderCatalogInspectionResult>.Succeeded(result, correlationId: correlationId);
        }
        catch (AgentCommandAuthorityExpiredException)
        {
            return AgentOperationResult<ProviderCatalogInspectionResult>.Succeeded(
                ProviderCatalogInspectionResult.NotAuthorized(), correlationId: correlationId);
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            cancellationToken.ThrowIfCancellationRequested();
            return context.HasCurrentAuthority
                ? AgentOperationResult<ProviderCatalogInspectionResult>.Failed(AgentCommandDispatchFailure.Map(exception), correlationId)
                : AgentOperationResult<ProviderCatalogInspectionResult>.Succeeded(ProviderCatalogInspectionResult.NotAuthorized(), correlationId: correlationId);
        }
    }

'''+s[end:]
# Tenant list/detail reads retain the same proof through both model reads and every helper await.
start=s.index('    private async ValueTask<AgentOperationResult<TenantProviderCatalogInspectionResult>> ReadTenantAsync(');end=s.index('    private async Task<ProviderCatalogReadModel?> ReadPlatformModelAsync(',start)
part=s[start:end]
part=part.replace('''            ReadModelEntry<TenantProviderEnablementReadModel> tenant =''','''            ct.ThrowIfCancellationRequested();
            context.Authority?.ThrowIfNotCurrent();
            ReadModelEntry<TenantProviderEnablementReadModel> tenant =''')
part=part.replace('''            if (tenant.Value?.IsScopedTo''','''            ct.ThrowIfCancellationRequested();
            context.Authority?.ThrowIfNotCurrent();
            if (tenant.Value?.IsScopedTo''')
part=part.replace('providerId, modelId, ct).ConfigureAwait(false)','providerId, modelId, ct, context.Authority).ConfigureAwait(false)')
part=part.replace('''                return AgentOperationResult<TenantProviderCatalogInspectionResult>.Succeeded(
                    pending''','''                context.Authority?.ThrowIfNotCurrent();
                return AgentOperationResult<TenantProviderCatalogInspectionResult>.Succeeded(
                    pending''')
part=part.replace('''            return AgentOperationResult<TenantProviderCatalogInspectionResult>.Succeeded(
                create(platform.Value, tenant.Value ?? new TenantProviderEnablementReadModel()),
                correlationId: options?.CorrelationId);''','''            TenantProviderCatalogInspectionResult result = create(platform.Value, tenant.Value ?? new TenantProviderEnablementReadModel());
            context.Authority?.ThrowIfNotCurrent();
            return AgentOperationResult<TenantProviderCatalogInspectionResult>.Succeeded(result, correlationId: options?.CorrelationId);''')
part=part.replace('''        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            return AgentOperationResult<TenantProviderCatalogInspectionResult>.Failed(''','''        catch (AgentCommandAuthorityExpiredException)
        {
            return AgentOperationResult<TenantProviderCatalogInspectionResult>.Succeeded(
                new(ProviderCatalogInspectionStatus.NotAuthorized, []), correlationId: options?.CorrelationId);
        }
        catch (Exception exception) when (exception is not OperationCanceledException)
        {
            ct.ThrowIfCancellationRequested();
            if (!context.HasCurrentAuthority)
            {
                return AgentOperationResult<TenantProviderCatalogInspectionResult>.Succeeded(
                    new(ProviderCatalogInspectionStatus.NotAuthorized, []), correlationId: options?.CorrelationId);
            }
            return AgentOperationResult<TenantProviderCatalogInspectionResult>.Failed(''')
s=s[:start]+part+s[end:]
s=s.replace('private async Task<ProviderCatalogReadModel?> ReadPlatformModelAsync(CancellationToken ct)','private async Task<ProviderCatalogReadModel?> ReadPlatformModelAsync(CancellationToken ct, AgentAuthorityValidity? authority = null)')
s=s.replace('''        return entry.Value;
    }
''','''        ct.ThrowIfCancellationRequested();
        authority?.ThrowIfNotCurrent();
        return entry.Value;
    }
''')
p.write_text(s,newline='\r\n')
