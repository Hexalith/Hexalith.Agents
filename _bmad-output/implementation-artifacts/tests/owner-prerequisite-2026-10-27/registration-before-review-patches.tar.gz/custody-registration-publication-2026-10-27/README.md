# Custody registration original publication source delivery

This is the registration-publication prerequisite from the approved Story 5.4 execution slice, against Platform source baseline `b117945e2ba7911fd2c47843f866487341300398`. It supplies source and diagnostic component evidence only. Story 5.4 and the broader owner deliveries remain in-progress; the four accepted dependencies remain Committed/unavailable and protection remains Uncommitted.

`IndependentAuthorityReceiver` now accepts `custody-publish-registration-original` only from a current, non-revoked `custody-registration-publisher` grant scoped to the exact tenant. Admission verifies the complete submitted registration through the installed `CustodyLifecycleClient.LookupOriginalAsync` path. That path authenticates the component response and compares the registration to its immutable wrap original. It is never sufficient to submit index facts. The receiver preserves the complete registration unchanged in its existing independent head, uses ETag CAS and signed nonce-bound replies, refuses conflicting identities/operations/references, retains the 1,000-registration and 32 MiB head bounds, reserves existing completion space for new admission, and performs no eviction. Even duplicate publication crosses the CAS/revocation barrier after verification.

`KeyExchange` requires an explicit publisher before a new wrap. After retaining the native result and committing the verified wrap response/checkpoint, it publishes that original before returning. A publication refusal or lost acknowledgement leaves the original recoverable even when the caller received no registration. Duplicate wrap calls and the existing `recover-wrap-result` worker recover/publish the same original; already-durable/closed intents are accepted for this recovery without reallocation or native wrapping. `SemanticProvider` shares its immutable-original validation with publication and continues to authenticate subsequent registration use. No root/KEK/decryption bytes enter publication.

## Explicit installation bindings remain unapplied

- Component `ComponentProfile.RegistrationPublisher`: an independently enrolled `IndependentDaprAuthorityBinding` with restricted mounted publisher credential, service/public trust, enrollment, scope and trust revision. Its null omission preserves old profile serialization; absence refuses new wraps before native work.
- Receiver `IndependentAuthorityReceiverInstallation.RegistrationVerifier`: actual semantic Dapr binding, owner-purpose scope, exact public component enrollment and response key, independent authorizer app ID and restricted mounted lookup credential reference. Absence refuses publication; existing read-only locator behavior remains available only under its existing enrolled grant.
- Existing independently administered store/head/genesis/incarnation, current tenant caller grant, trust/revocation, channel credential and public signer installation. Startup creates none of these. Lookup remains a hint; custody use still authenticates the actual original.

No installation, deployment, trust/genesis/credential generation, native resource operation, Live/Full/cohort qualification, consuming seam or separate manifest publisher was run or added. A non-AWS physical provider, independent resources/administrators, original authority/archive installation, exact trust and public anchors, measured capacity/closure, physical non-revival and survivor recovery remain required. OpenBao ObservedRevival evidence and AWS exclusion are unchanged. Branch B, 365 fixed days, host 192.168.1.30, timing 300/30/600/86400/604800 and every qualification/physical gate remain unchanged.

## Verification and limits

Commands ran from the root-declared Platform checkout, with Debug assets isolated at `/tmp/hexalith-custody-registration-20261027/runtime`. `evidence/verification.json` records exact commands, exits, results and source/log hashes. Retained logs and xUnit XML are in [evidence](evidence/).

| Gate | Result |
| --- | --- |
| Normal Runtime test-project Debug build, analyzers enabled | Exit 1: unchanged `CustodyOutsideWitness.TryRepromote` CA1822 at line 143. |
| Normal component test-project Debug build, analyzers enabled | Exit 1: same unchanged CA1822 dependency blocker. |
| Focused Runtime build with `BuildProjectReferences=false`, analyzers enabled | Exit 1: 106 existing project analyzer errors (including CA2007/CA1062); no diagnostics on new registration files. Unchanged dependency DLLs inspected in prior `/tmp` lanes did not match the current diagnostic DLL hash, so no matching retained dependency asset is claimed. |
| Diagnostic Runtime test-project Debug build with `RunAnalyzers=false` | Exit 0, zero compiler warnings/errors. This does not pass the normal analyzer gate. |
| Diagnostic component test-project Debug build with `RunAnalyzers=false` | Exit 0, zero compiler warnings/errors. This does not pass the normal analyzer gate. |
| Direct xUnit assembly, two explicit focused classes | Exit 0: 33 passed, zero failed/skipped/not-run, including all five new publication tests; names retained in XML. |
| Direct component assembly, nine explicit registered scenarios | Exit 0: 9 passed, zero failed; `sourceComponentOnly=true physicalQualification=false`. |

The normal build gate remains failed. No suppression or unrelated source repair was persisted. All fixture credentials, state, signing keys and native doubles are disposable test inputs and establish no production enrollment or physical guarantee. The independent receiver tests assert persisted head contents across receiver reconstruction. The component tests exercise the actual signed SDK/component original verifier and prove publication loss/recovery does not increase native wrap counts.

| Spec matrix row | Executed coverage |
| --- | --- |
| First publication | `VerifiedOriginalPersistsAcrossRestartAndLostPublicationAcknowledgement`; `registration-publication-loss-restart-and-no-native-resend` checks the component durable original before publishing. |
| Duplicate/loss | Same Runtime test; component `registration-publication-loss-restart-and-no-native-resend` and `lost-wrap-result-recovers-without-native-resend`: unreceived original, publication outage, lost acknowledgement, reconstructed component, exact worker/duplicate recovery and one native wrap total. |
| Scope/authority | `ScopeRoleRevocationAndExpiredCurrentHeadDenyBeforeOriginalVerificationOrDisclosure`; `RevocationDuringVerificationWinsConditionalPublication`; missing verifier/original refusal. |
| Substitution | `MissingVerifierOrOriginalAndAllChangedRegistrationFieldsDenyIndexMutation`; actual signed SDK verifier in the new component scenario checks every identity member, operation, actor revision, KEK, reference and receipt; existing `registration-only-original-lookup-and-substitution-denial`. |
| Capacity/cancellation | `CapacityCasLossOutageAndCancellationPreserveOriginalWithoutFabricatedSuccess`: 1,000 retained registrations, oversized current head, CAS loss, verifier outage, cancellation, no eviction or fabricated success and exact later recovery. Component scenario rejects changed publication replies/cancellation. |

The other component scenarios executed were public lifecycle SDK/authorizer/cleanup/refusals, missing qualification/enrollment refusal, ephemeral delivery/holder completion, OpenBao HTTP metadata/AEAD fixture behavior, maximum immutable checkpoint roundtrip and shared-cut original page recovery. These are source fixtures; no real native key work occurred.

Reuse unchanged evidence outside this slice: the October 27 Agents verification receipt/archive and the parent preservation receipt named by the root execution spec, the accepted dependency-register snapshot, prior owner reconciliation and installation packet, retained physical evidence and original attempt/recovery journals. The parent's exact Aspire baseline attempt timed out and subsequently reported no AppHost running; no resource-readiness baseline was established or substituted by starting installed services. No full Agents matrix was rerun. Parent workflow review and final acceptance remain the parent's responsibility.
