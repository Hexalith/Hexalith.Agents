import json,os,pathlib,subprocess,sys
scratch=pathlib.Path('/tmp/agents-story54-approver-lifetime-20261031')
preparation=json.loads((scratch/'focused-preparation.json').read_text())
assert preparation['status']=='prepared'
mode=sys.argv[1]
env=os.environ.copy()
env.update(preparation['buildPreparation']['environment'])
cmd=['dotnet','build','test/Hexalith.Agents.Server.Tests/Hexalith.Agents.Server.Tests.csproj','--configuration','Debug','-m:1','-p:MinVerVersionOverride=1.0.0','--nologo']
if mode=='red': cmd.append('-p:CustomAfterMicrosoftCommonTargets='+str(scratch/'prior-source.targets'))
(scratch/(mode+'-build-command.json')).write_text(json.dumps(cmd))
with (scratch/(mode+'-build.log')).open('w') as log:
    code=subprocess.call(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
print('Build exit',code,flush=True)
if code: print((scratch/(mode+'-build.log')).read_text()[-10000:]);sys.exit(code)
classes=['ApproverAuthorityLifetimeTests'] if mode!='compatibility' else ['AgentsEventStoreGatewayIntegrationTests','ProviderCatalogCoordinationIntegrationTests','FixtureAgentRouteCatalogTests']
cmd=['dotnet','test/Hexalith.Agents.Server.Tests/bin/Debug/net10.0/Hexalith.Agents.Server.Tests.dll',*[value for name in classes for value in ['-class','Hexalith.Agents.Server.Tests.'+name]],'-result-xml',str(scratch/(mode+'.xml'))]
(scratch/(mode+'-test-command.json')).write_text(json.dumps(cmd))
with (scratch/(mode+'-test.log')).open('w') as log:
    code=subprocess.call(cmd,stdout=log,stderr=subprocess.STDOUT)
print((scratch/(mode+'-test.log')).read_text()[-12000:]);sys.exit(code)
