import hashlib,json,pathlib,subprocess,zipfile,datetime,re
from xml.etree import ElementTree as ET
root=pathlib.Path.cwd(); scratch=pathlib.Path('/tmp/agents-story54-approver-lifetime-20261031')
before=json.loads((scratch/'source-before.json').read_text())
after={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in before}
(scratch/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
assert before==after,'Selected source changed during verification'
revisions=json.loads((scratch/'revisions-before.json').read_text())
current={name:{'revision':subprocess.check_output(['git','-C',name,'rev-parse','HEAD'],text=True).strip(),'status':subprocess.check_output(['git','-C',name,'status','--porcelain'],text=True)} for name in revisions}
(scratch/'revisions-after.json').write_text(json.dumps(current,indent=2)+'\n')
assert all(revisions[name]['revision']==current[name]['revision'] for name in revisions),'Canonical revision changed'
assert all(revisions[name]['status']==current[name]['status'] for name in revisions if name!='.'),'Reference checkout changed'
def results(path):
 assemblies=ET.parse(path).findall('./assembly')
 return {key:sum(int(a.get(key,'0')) for a in assemblies) for key in ['total','passed','failed','errors','skipped','not-run']}
projects={path.stem:results(path) for path in sorted((scratch/'local').glob('*.xml'))}
assert len(projects)==5 and all(v['total']>0 and v['total']==v['passed'] and not any(v[k] for k in ['failed','errors','skipped','not-run']) for v in projects.values())
assert all('0 Warning(s)' in path.read_text() for path in (scratch/'local').glob('*.build.log'))
local=json.loads((scratch/'local/result.json').read_text()); live=json.loads((scratch/'live/result.json').read_text())
assert local['LocalContractsVerified'] and not local['StoryComplete'] and live['ExternalCalls']==0 and len(live['Blockers'])==4
artifacts={}
for config in ['Debug','Release']:
 for project in (root/'test').iterdir():
  if not project.is_dir():continue
  for suffix in ['dll','pdb']:
   p=project/'bin'/config/'net10.0'/(project.name+'.'+suffix)
   if p.is_file():artifacts[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
commands={
 'local':'pwsh -NoProfile -File ./eng/verify-story-5.4.ps1 -Mode Local -ArtifactsPath '+str(scratch/'local'),
 'live':'pwsh -NoProfile -File ./eng/verify-story-5.4.ps1 -Mode Live -ArtifactsPath '+str(scratch/'live'),
 'packageBuild':'dotnet build test/Hexalith.Agents.Server.Tests/Hexalith.Agents.Server.Tests.csproj --configuration Release -p:UseHexalithProjectReferences=false -p:MinVerVersionOverride=1.0.0 -m:1 --nologo',
 'packageTests':'dotnet test/Hexalith.Agents.Server.Tests/bin/Release/net10.0/Hexalith.Agents.Server.Tests.dll -result-xml '+str(scratch/'package.xml'),
 'tooling':'python3 -m unittest discover -s tests/tooling -p story_54_verifier_test.py',
}
register=(root/'_bmad-output/planning-artifacts/external-dependency-register.md').read_text()
records={}
for name in ['EXT-PARTIES-1','EXT-CONV-AI-1','EXT-SECRETS-1','EXT-HOST-1']:
 section=re.search(r'^### '+re.escape(name)+r' \u2014.*?(?=^### |\Z)',register,re.M|re.S).group()
 records[name]={field:re.search(r'\| `'+field+r'` \| `([^`]+)`',section).group(1) for field in ['TargetVersionOrCommit','TargetIntegrationDate','AcceptedStatus']}
remaining=[
 'Production current tenant/actor/Party/approver sources, custody and immutable provisioning remain unbound.',
 'AD-30 signature/principal/operation/scope admission and private durable replay registration remain unavailable.',
 'Replicated denial spool, restricted worker credentials and persisted ACL/outage/restart/restore/isolation matrix remain unavailable.',
 'Production Agents intent adapters still need declared catalog enrollment and the exact authenticated host/gateway integration for the newer source SDK; the compatibility wrappers and TestServer principals are local fixtures only.',
 'Proposal approval/rejection/abandonment/edit/regeneration operations remain unavailable with no runtime callers; when wired, preserve the returned approver bound through their later work and final dispatch.',
 'Full Story 5.4 tasks/status, accepted dependency pins and RQ-1 remain unchanged; no owner command was repeated and no full-story review began.',
]
receipt={'createdUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'story':'5.4','scope':'Bounded confirmed-approver lifetime and local SDK fixture compatibility','storyComplete':False,'status':'in-progress','originalBaselineCommit':'4e79df1f8b4e91c8f7ec73f935ed9212950b596b','commands':commands,'sdk':subprocess.check_output(['dotnet','--version'],text=True).strip(),'canonicalRevisions':current,'dependencyRecords':records,'sourceAudit':{'selectedRootFiles':len(before),'changedFiles':[],'scope':'Selected root sources, tests, tooling, configuration and register. Generated and transitive compiler inputs are not attested.'},'local':{'projects':projects,'total':sum(v['total'] for v in projects.values()),'warningFreeBuilds':5,'result':local},'live':live,'priorSourceDiagnostic':{'result':results(scratch/'red.xml'),'overlay':'Seven production files read from HEAD, with only the two then-incompatible SDK integration test files excluded in this focused diagnostic. Original broad constructor/fixture errors are retained in initial-red-build.log. No owner source was edited. The red test DLL/PDB was not retained.','finalFocused':results(scratch/'green.xml')},'package':{'version':'3.128.4','warningFreeBuild':True,'result':results(scratch/'package.xml'),'scope':'Complete Server suite; source-only route/auth fixtures excluded, original package API path retained.'},'tooling':{'passed':6,'failed':0,'scope':'Six unittest methods, including producer-validation subcases; final verifier suite list is included.'},'artifactSha256':artifacts,'remaining':remaining}
evidence=root/'_bmad-output/implementation-artifacts/tests/story-5-4-approver-lifetime-2026-10-31'
evidence.mkdir(parents=True,exist_ok=True)
include=[]
for p in scratch.rglob('*'):
 if p.is_file() and not any(part in {'source-mapping','focused-preparation','preparation'} or part.startswith('build-preparation-') for part in p.relative_to(scratch).parts) and p.suffix in {'.log','.xml','.json','.txt','.targets','.cs','.py'}:include.append(p)
with zipfile.ZipFile(evidence/'evidence.zip','w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(include):archive.write(p,str(p.relative_to(scratch)))
receipt['archiveSha256']=hashlib.sha256((evidence/'evidence.zip').read_bytes()).hexdigest()
(evidence/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(evidence/'verification.json'),'localTotal':receipt['local']['total'],'projects':projects,'selectedInputs':len(before),'archiveBytes':(evidence/'evidence.zip').stat().st_size},indent=2))
