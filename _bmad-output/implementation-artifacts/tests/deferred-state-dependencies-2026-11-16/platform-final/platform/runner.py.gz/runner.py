#!/usr/bin/env python3
"""Replay the three independent deferred dependency experiments without changing checkout pins.

Run under run-with-temp. Exact archives, commands, native XML, mappings and input/output
hashes are retained in --evidence. A failed build is blocked evidence, never proof that a
pin is necessary. No audit/test gate is suppressed and no packages are published.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import re
from pathlib import Path
import shutil
import subprocess
import tarfile
import time
import xml.etree.ElementTree as ET

RUNNER_SOURCE = Path(__file__).read_bytes()
ROOT = Path(__file__).resolve().parents[1]
CURRENT = "f90e43f2e048f3b9ef77e7445eaa51544b76536d"
REVIEWED = "13857fd86e9fda7e2ba0f4017aadb042750e4284"
PREVIOUS = "599208dd40efadef728363c227a0f75ebd888337"
PLATFORM = "17b1f688b332020fafbe1da07a5c04a41886c7bd"
EVENTSTORE = "eecc0e4da70a0d64aaeff4fb75cdc06f94eb7563"
RELEASED = "f792bba6c0564d3c36dda6ad1c2fc55b0b0a6331"
HISTORICAL_EVENTSTORE = "4bc61d9a60fae13a65f23963c1cb731065222f2a"
FIVE = ("Builds", "Commons", "Conversations", "FrontComposer", "PolymorphicSerializations")
ORIGINAL_METHODS = (
    "StaticValidityRequiresExplicitProjectAndScopedConfigurationBeforeComposition",
    "SignedPartiesRunUsesTheRunnerJwtSettingsAsync",
    "CompositionWiresSingularPartyGatewayAndDeclarativeTenantSubscription",
)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(repo), *args], stderr=subprocess.PIPE)


def pins(repo, revision):
    return {line.split("\t")[1].split("/")[-1]: line.split()[2]
            for line in git(repo, "ls-tree", "-r", revision, "references").decode().splitlines()
            if line.startswith("160000 ")}


def owner_repository(name, revision):
    candidates = [ROOT / "references" / name, ROOT.parent / name.removeprefix("Hexalith.").lower()]
    if name == "Hexalith.Agents":
        candidates.insert(0, ROOT)
    if name == "Hexalith.AI.Tools":
        candidates.append(ROOT.parent / "aitools")
    for repo in candidates:
        try:
            git(repo, "cat-file", "-e", revision + "^{commit}")
            return repo
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass
    raise RuntimeError(f"Exact local object unavailable: {name}@{revision}")


class Experiment:
    def __init__(self, name, scratch, evidence):
        self.name = name
        self.work = scratch / name
        self.work.mkdir()
        self.evidence = evidence / name
        self.evidence.mkdir(parents=True, exist_ok=True)
        self.record = {"name": name, "status": "blocked", "commands": [], "exports": [], "runnerSha256": digest(RUNNER_SOURCE)}
        (self.evidence / "runner.py").write_bytes(RUNNER_SOURCE)

    def save(self):
        files = {}
        for path in self.evidence.rglob("*"):
            if path.is_file() and path.name != "result.json":
                files[str(path.relative_to(self.evidence))] = digest(path.read_bytes())
        self.record["evidenceSha256"] = files
        (self.evidence / "result.json").write_text(json.dumps(self.record, indent=2) + "\n")

    def run(self, label, args, cwd, environment=None, required=True):
        args = list(map(str, args))
        print(f"{self.name}: starting {label}", flush=True)
        started = time.monotonic()
        log = self.evidence / (label + ".log")
        with log.open("wb") as output:
            try:
                result = subprocess.run(args, cwd=cwd, env=environment, stdout=output,
                                        stderr=subprocess.STDOUT, timeout=1800, check=False)
                code = result.returncode
            except subprocess.TimeoutExpired:
                code = 124
                output.write(b"\nVerification timeout; execution is incomplete.\n")
        self.record["commands"].append({"label": label, "argv": args, "cwd": str(cwd),
            "environment": {key: value for key, value in (environment or {}).items()
                            if key.startswith("HEXALITH_") or key.startswith("Custom")},
            "exitCode": code, "elapsedSeconds": round(time.monotonic() - started, 3),
            "logSha256": digest(log.read_bytes())})
        self.save()
        print(f"{self.name}: {label}: exit {code}", flush=True)
        if code and required:
            raise RuntimeError(f"{label} exited {code}; see {log.name}")
        return code

    def export(self, name, revision, destination):
        repo = owner_repository(name, revision)
        canonical = git(repo, "rev-parse", revision + "^{commit}").decode().strip()
        if canonical != revision:
            raise ValueError("An exact full revision is required")
        data = git(repo, "archive", "--format=tar", revision)
        destination.mkdir(parents=True, exist_ok=True)
        with tarfile.open(fileobj=io.BytesIO(data)) as archive:
            archive.extractall(destination, filter="data")
        # Real objects/index preserve producer identity checks in disposable exports.
        # No submodule update or nested checkout is performed.
        git(destination, "init", "-q")
        objects = Path(git(repo, "rev-parse", "--git-path", "objects").decode().strip())
        if not objects.is_absolute():
            objects = (repo / objects).resolve()
        alternates = destination / ".git/objects/info/alternates"
        alternates.write_text(str(objects) + "\n")
        git(destination, "update-ref", "HEAD", revision)
        git(destination, "read-tree", revision)
        remote = git(repo, "remote", "get-url", "origin").decode().strip()
        git(destination, "remote", "add", "origin", remote)
        print(f"{self.name}: exported {name}@{canonical}", flush=True)
        self.record["exports"].append({"owner": name, "revision": canonical,
            "sourceRepository": str(repo), "destination": str(destination), "archiveSha256": digest(data)})
        self.save()
        return destination

    def cohort(self, name, revision, selections=None, needed=None):
        repo = self.export(name, revision, self.work / name)
        selected = pins(owner_repository(name, revision), revision)
        selected.update(selections or {})
        for identity, commit in selected.items():
            if needed is None or identity in needed:
                self.export(identity, commit, repo / "references" / identity)
        self.record["selectedPins"] = selected
        return repo

    def tests(self, label, assembly, cwd, selectors=(), environment=None, minimum=1, methods=()):
        xml = self.evidence / (label + ".xml")
        self.run(label, ["dotnet", assembly, "-failSkips", *selectors, "-result-xml", xml], cwd, environment)
        root = ET.parse(xml).getroot()
        rows = root.findall(".//test")
        if len(rows) < minimum or any(row.get("result") != "Pass" for row in rows) or root.findall(".//error"):
            raise RuntimeError(f"{label}: failed, skipped, erroneous or insufficient native test discovery")
        for method in methods:
            if not any(method in row.get("name", "") for row in rows):
                raise RuntimeError(f"{label}: original case {method} did not execute")
        self.record[label] = {"passed": len(rows), "failed": 0, "skipped": 0,
                              "testNames": [row.get("name") for row in rows]}
        self.save()

    def prepare(self, repo):
        # Pre-materialize every declared root before invoking the producer. Its
        # initializer must never fetch missing roots or initialize nested modules.
        for name, revision in self.record["selectedPins"].items():
            owner_repository(name, revision)
        for name, revision in self.record["selectedPins"].items():
            destination = repo / "references" / name
            if not (destination / ".git").exists():
                self.export(name, revision, destination)
        builds = repo / "references/Hexalith.Builds"
        cli = builds / "src/libraries/Hexalith.Builds.Module.Cli/Hexalith.Builds.Module.Cli.csproj"
        self.run("producer-build", ["dotnet", "build", cli, "-c", "Debug", "-m:1", "-p:MinVerVersionOverride=1.0.0"], builds)
        tfm = json.loads((builds / "global.json").read_text())["sdk"]["version"].split('.')[0]
        assembly = cli.parent / f"bin/Debug/net{tfm}.0/Hexalith.Builds.Module.Cli.dll"
        # Preparation uses a generated declaration input at the exact cohort root.
        # Active identity must name that root; catalogue generation below still uses
        # the unchanged Conversations-owned declaration from the selected mapping.
        declaration = repo / "verification.module-manifest.v2.json"
        original = repo / "references/Hexalith.Conversations/module/hexalith.module-manifest.v2.json"
        declaration_input = json.loads(original.read_text())
        declaration_input["modules"][0]["identity"]["moduleId"] = repo.name.removeprefix("Hexalith.").lower()
        declaration.write_text(json.dumps(declaration_input, indent=2) + "\n")
        self.record["preparationDeclarationSha256"] = digest(declaration.read_bytes())
        shutil.copyfile(declaration, self.evidence / "preparation-declaration.json")
        workspace = self.work / "prepared"
        self.run("prepare-build", ["dotnet", assembly, "prepare-build", "--manifest", declaration,
                                   "--mode", "source", "--output", "json", "--workspace", workspace], repo)
        prepared = json.loads((self.evidence / "prepare-build.log").read_text())
        prepared = prepared.get("buildPreparation", prepared)
        (self.evidence / "preparation.json").write_text(json.dumps(prepared, indent=2) + "\n")
        shutil.copytree(workspace / "source-mapping", self.evidence / "source-mapping", dirs_exist_ok=True)
        environment = os.environ.copy()
        environment.update(prepared["environment"])
        self.record["producerMappingSha256"] = digest((workspace / "source-mapping/mapping.json").read_bytes())
        return workspace, prepared, environment


def graph(experiment, repo, label):
    pending = [repo / "src/Hexalith.Agents.EventStore/Hexalith.Agents.EventStore.csproj"]
    inventory = {}
    while pending:
        project = pending.pop()
        identity = str(project.relative_to(repo))
        if identity in inventory:
            continue
        tag = label + "-graph-" + project.stem
        experiment.run(tag, ["dotnet", "msbuild", project, "-nologo", "-p:Configuration=Debug",
            "-p:UseHexalithProjectReferences=true", "-getProperty:MSBuildAllProjects",
            "-getItem:Compile,EmbeddedResource,Content,None,ProjectReference,PackageReference,PackageVersion"], repo)
        evaluated = json.loads((experiment.evidence / (tag + ".log")).read_text())
        files = {}
        for kind in ("Compile", "EmbeddedResource", "Content", "None"):
            for item in evaluated["Items"].get(kind, []):
                path = Path(item["FullPath"])
                if path.is_file() and not any(part in ("bin", "obj") for part in path.parts):
                    key = str(path.relative_to(repo)) if path.is_relative_to(repo) else str(path)
                    files[key] = digest(path.read_bytes())
        # MSBuildAllProjects is a timestamp optimization, not a complete import list.
        # The expanded project's import comments identify the actual evaluated inputs.
        preprocessed = experiment.evidence / (tag + "-expanded.xml")
        experiment.run(tag + "-imports", ["dotnet", "msbuild", project, "-nologo", "-p:Configuration=Debug",
            "-p:UseHexalithProjectReferences=true", "-preprocess:" + str(preprocessed)], repo)
        imported_paths = re.findall(r"^(/[^\n<>]+\.(?:props|targets|csproj))\s*$", preprocessed.read_text(), re.MULTILINE)
        for imported in [str(project), *imported_paths]:
            path = Path(imported.strip())
            if path.is_file():
                key = str(path.relative_to(repo)) if path.is_relative_to(repo) else str(path)
                files[key] = digest(path.read_bytes())
        inventory[identity] = {"files": files, "packages": [
            {key: item.get(key) for key in ("Identity", "Version", "VersionOverride", "IncludeAssets", "ExcludeAssets", "PrivateAssets")}
            for kind in ("PackageReference", "PackageVersion") for item in evaluated["Items"].get(kind, [])]}
        for item in evaluated["Items"].get("ProjectReference", []):
            target = Path(item["FullPath"])
            if not target.is_relative_to(repo):
                raise RuntimeError("Consumed graph escaped the exported cohort")
            pending.append(target)
    (experiment.evidence / (label + "-graph.json")).write_text(json.dumps(inventory, indent=2) + "\n")
    return inventory


def current(experiment):
    repo = experiment.cohort("Hexalith.Agents", CURRENT)
    selected = graph(experiment, repo, "selected")
    eventstore = repo / "references/Hexalith.EventStore"
    shutil.rmtree(eventstore)
    experiment.export("Hexalith.EventStore", RELEASED, eventstore)
    released = graph(experiment, repo, "released")
    experiment.record["completeConsumedGraphsEqual"] = selected == released
    experiment.record["graphProjectCount"] = len(selected)
    shutil.rmtree(eventstore)
    experiment.export("Hexalith.EventStore", EVENTSTORE, eventstore)
    project = "src/Hexalith.Agents.EventStore/Hexalith.Agents.EventStore.csproj"
    for configuration in ("Debug", "Release"):
        experiment.run("integration-" + configuration, ["dotnet", "build", project, "-c", configuration,
                       "-m:1", "-p:MinVerVersionOverride=1.0.0"], repo)
        captured = {}
        for asset in repo.rglob("project.assets.json"):
            if asset.parent.name == "obj":
                document = json.loads(asset.read_text())
                captured[str(asset.relative_to(repo))] = {
                    "sha256": digest(asset.read_bytes()), "libraries": document["libraries"],
                    "projectFileDependencyGroups": document.get("projectFileDependencyGroups"),
                    "targets": {name: list(target) for name, target in document["targets"].items()}}
        (experiment.evidence / ("resolved-assets-" + configuration + ".json")).write_text(json.dumps(captured, indent=2) + "\n")
        outputs = repo / "src/Hexalith.Agents.EventStore/bin" / configuration
        (experiment.evidence / ("integration-output-hashes-" + configuration + ".json")).write_text(json.dumps({
            str(path.relative_to(outputs)): digest(path.read_bytes()) for path in outputs.rglob("*") if path.is_file()}, indent=2) + "\n")
    experiment.run("package-floor", ["pwsh", "-NoProfile", "-File", "eng/verify-story-5.2.ps1", "-PackageFloorOnly"], repo)
    server = "test/Hexalith.Agents.Server.Tests/Hexalith.Agents.Server.Tests.csproj"
    # Preserve the default broad source failure independently of mapped integration.
    experiment.run("server-default-source", ["dotnet", "build", server, "-c", "Debug", "-m:1",
                   "-p:MinVerVersionOverride=1.0.0"], repo, required=False)
    experiment.run("server-packages", ["dotnet", "build", server, "-c", "Release",
                   "-m:1", "-p:MinVerVersionOverride=1.0.0"], repo)
    experiment.tests("gateway-Release",
        repo / "test/Hexalith.Agents.Server.Tests/bin/Release/net11.0/Hexalith.Agents.Server.Tests.dll", repo,
        ["-class", "Hexalith.Agents.Server.Tests.AgentsEventStoreGatewayIntegrationTests"])
    _, _, environment = experiment.prepare(repo)
    experiment.run("server-mapped-source", ["dotnet", "build", server, "-c", "Debug", "-m:1",
                   "-p:MinVerVersionOverride=1.0.0"], repo, environment)
    experiment.tests("gateway-Debug",
        repo / "test/Hexalith.Agents.Server.Tests/bin/Debug/net11.0/Hexalith.Agents.Server.Tests.dll", repo,
        ["-class", "Hexalith.Agents.Server.Tests.AgentsEventStoreGatewayIntegrationTests"], environment)
    if not experiment.record["completeConsumedGraphsEqual"]:
        raise RuntimeError("Consumed source graph changed; reconciliation requires analysis")
    experiment.record["status"] = "passed"


def historical(experiment):
    old_pins = pins(ROOT, PREVIOUS)
    reviewed_pins = pins(ROOT, REVIEWED)
    outcomes = {}
    for selection, selected in (("reviewed", reviewed_pins), ("previous-five", old_pins)):
        lane = Experiment(selection, experiment.work, experiment.evidence)
        try:
            overrides = {"Hexalith." + name: selected["Hexalith." + name] for name in FIVE}
            overrides["Hexalith.EventStore"] = HISTORICAL_EVENTSTORE
            repo = lane.cohort("Hexalith.Agents", REVIEWED, overrides)
            lane.record["onlyVariedOwners"] = ["Hexalith." + name for name in FIVE]
            lane.run("integration-build", ["dotnet", "build", "test/Hexalith.Agents.Server.Tests/Hexalith.Agents.Server.Tests.csproj",
                     "-c", "Debug", "-m:1", "-p:MinVerVersionOverride=1.0.0"], repo)
            lane.tests("gateway", repo / "test/Hexalith.Agents.Server.Tests/bin/Debug/net10.0/Hexalith.Agents.Server.Tests.dll",
                       repo, ["-class", "Hexalith.Agents.Server.Tests.AgentsEventStoreGatewayIntegrationTests"])
            lane.record["status"] = "passed"
        except Exception as error:
            lane.record["blocker"] = str(error)
        lane.save()
        outcomes[selection] = lane.record["status"]
    experiment.record["outcomes"] = outcomes
    if set(outcomes.values()) == {"passed"}:
        experiment.record["status"] = "passed"
        experiment.record["conclusion"] = "Both exact historical integrations execute; the five reviewed pin changes were not necessary for this selected integration. No current rollback is implied."
    else:
        experiment.record["blocker"] = "At least one historical lane did not execute; pin necessity is unresolved."


def platform(experiment):
    needed = {"Hexalith." + name for name in ("Builds", "EventStore", "Tenants", "Memories", "Parties",
              "Commons", "McpCli", "PolymorphicSerializations", "Conversations", "FrontComposer", "AI.Tools")}
    repo = experiment.cohort("Hexalith.Platform", PLATFORM, needed=needed)
    project = "tests/Hexalith.Platform.Composition.Tests/Hexalith.Platform.Composition.Tests.csproj"
    # All owner paths are explicit; these are the Platform-recorded owners, never Agents umbrella pins.
    properties = [f"-p:Hexalith{name.removeprefix('Hexalith.').replace('.', '')}Root={repo / 'references' / name}"
                  for name in experiment.record["selectedPins"] if name != "Hexalith.AI.Tools"]
    common = ["dotnet", "build", project, "-c", "Debug", "-m:1", "-p:MinVerVersionOverride=1.0.0", *properties]
    default = experiment.run("default-source-build", common, repo, required=False)
    assembly = repo / "tests/Hexalith.Platform.Composition.Tests/bin/Debug/net11.0/Hexalith.Platform.Composition.Tests.dll"
    if default == 0:
        experiment.tests("default-related", assembly, repo,
            ["-class", "Hexalith.Platform.Composition.Tests.DomainEnrollmentBindingTests", "-class", "Hexalith.Platform.Composition.Tests.PartiesAdoptionTests"],
            minimum=8, methods=ORIGINAL_METHODS)
    workspace, prepared, environment = experiment.prepare(repo)
    inputs = {"producerMappingPath": str(workspace / "source-mapping/mapping.json"), "producerMappingHash": prepared["mappingHash"],
              "mappingPath": str(workspace / "source-mapping/mapping.json"), "mappingHash": prepared["mappingHash"],
              "evidenceRoot": str(experiment.evidence / "catalog")}
    inputs_path = experiment.evidence / "catalog-inputs.json"
    inputs_path.write_text(json.dumps(inputs, indent=2) + "\n")
    environment["HEXALITH_CONVERSATIONS_CATALOG_INPUTS"] = str(inputs_path)
    experiment.run("mapped-source-build", [*common, "-p:ConversationsCatalogSourceVerification=true"], repo, environment)
    experiment.tests("mapped-catalog", assembly, repo,
        ["-class", "Hexalith.Platform.Composition.Tests.ConversationsEnrollmentTests"], environment, minimum=38)
    experiment.tests("mapped-related", assembly, repo,
        ["-class", "Hexalith.Platform.Composition.Tests.DomainEnrollmentBindingTests", "-class", "Hexalith.Platform.Composition.Tests.PartiesAdoptionTests"],
        environment, minimum=8, methods=ORIGINAL_METHODS)
    if default != 0:
        raise RuntimeError("Default exact Platform source graph remains blocked; mapped evidence is separate")
    experiment.record["status"] = "passed"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lane", choices=("all", "current", "historical", "platform"), default="all")
    parser.add_argument("--evidence", type=Path, required=True)
    args = parser.parse_args()
    if not os.environ.get("TMPDIR"):
        parser.error("run under run-with-temp to provide a private disposable TMPDIR")
    scratch = Path(os.environ["TMPDIR"]).resolve() / "deferred-dependencies"
    scratch.mkdir()
    evidence = args.evidence.resolve()
    if evidence.is_relative_to(scratch.parent):
        parser.error("evidence must survive outside TMPDIR")
    results = {}
    for name, execute in (("current", current), ("historical", historical), ("platform", platform)):
        if args.lane not in ("all", name):
            continue
        experiment = Experiment(name, scratch, evidence)
        try:
            execute(experiment)
        except Exception as error:
            experiment.record["blocker"] = str(error)
        finally:
            experiment.save()
        results[name] = experiment.record
    (evidence / "dependency-results.json").write_text(json.dumps(results, indent=2) + "\n")
    return 0 if all(result["status"] == "passed" for result in results.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())
